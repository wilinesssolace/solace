# 《运动处方》第2版 · 第二章教学样章

- `chapter2-slides.pdf`：70页、16:9课件。
- `chapter2-lesson-plan.pdf`：配套教案，按4课时×45分钟设计，含课堂记录单、答案、作业评价和教材映射。
- 两个同名 `.tex` 文件：可编辑LaTeX源码。
- `course-style.sty`：课件主题；`assets/`：从用户参考课件中提取的校徽与校名图。
- `slide-map.json`：课件页码、标题及教材印刷页码对照。

## 编译

需要XeLaTeX，以及beamer、fontspec、lmodern、TikZ、booktabs、tabularx、geometry、fancyhdr、enumitem、titlesec等常用TeX包；字体使用Noto Sans CJK SC与Noto Serif CJK SC。无需网络图片或在线编译服务。

在本目录运行：

```bash
bash build.sh
```

每份文件需编译两次，以更新页数与PDF内部链接。保持assets目录和course-style.sty与主文件的相对位置不变。

## 使用说明

内容依据为用户提供的教材第二章（印刷页码19—92），版式依据为《极限的运算》。按教学需要删减长篇常模表并增加自编案例和计算题；保留教材出处，未擅自填写教师姓名或日期。

风险分层和部分评价体系按教材第2版表述，正式测试应结合现行规范、具体人群及完整操作方案。课堂示意图不代替完整操作指导。示例人物和数据均用于教学。
