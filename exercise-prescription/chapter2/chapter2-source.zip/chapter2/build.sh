#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for name in chapter2-slides chapter2-lesson-plan; do
  xelatex -interaction=nonstopmode -halt-on-error "$name.tex"
  xelatex -interaction=nonstopmode -halt-on-error "$name.tex"
done
