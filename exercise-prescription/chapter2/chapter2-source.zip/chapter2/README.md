# 《运动处方》第2版 · 第二章：运动人体科学专业教学版

- chapter2-slides.pdf：70页16:9课件，围绕生理机制、测评技术、结果解释和处方衔接。
- chapter2-lesson-plan.pdf：10页配套教案，4课时×45分钟，含课堂记录单、案例研判与作业评价。
- 两个同名.tex文件：可编辑LaTeX源码。
- course-style.sty与assets/：课件主题和用户参考课件中的校徽、校名素材。
- slide-map.json：页码与教材内容对照。

## 编译

使用XeLaTeX，安装Noto Sans CJK SC、Noto Serif CJK SC字体和常用TeX包（beamer、fontspec、lmodern、TikZ、booktabs、tabularx、geometry、fancyhdr、enumitem、titlesec等）。在本目录运行：

```bash
bash build.sh
```

主文件各编译两次以更新页数。保留主题与素材的相对路径。

## 教学内容

教材依据：用户上传《运动处方》第2版第二章，教材印刷页码19—92。

案例重点包括：活动相关症状的风险决策、同负荷心率变化的生理解释、老年人功能任务选择、脂肪分布与身体机能、BIA与体液状态，以及柔韧性测量的质量控制。课堂考核关注机制、技术、结果和决策。

生理机制解释及案例为教学补充，课件已注明；长篇常模表请查阅教材。正式测试按适用规程及监督要求实施。紫白视觉版式沿用用户提供的《极限的运算》。
